# -*- coding: utf-8 -*-

## \package input
#  
#  Package for custom input controls

# MIT licensing
# See: docs/LICENSE.txt
