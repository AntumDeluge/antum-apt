# -*- coding: utf-8 -*-

## \package startup.__init__

# MIT licensing
# See: docs/LICENSE.txt
