# -*- coding: utf-8 -*-

## \package startup
#
#  Modules related to application initialization

# MIT licensing
# See: docs/LICENSE.txt
