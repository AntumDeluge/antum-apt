# -*- coding: utf-8 -*-

## \package system
#
#  Functions related to the local system

# MIT licensing
# See: docs/LICENSE.txt
