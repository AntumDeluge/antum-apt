# -*- coding: utf-8 -*-

## \package globals
#
#  General helper modules

# MIT licensing
# See: docs/LICENSE.txt
